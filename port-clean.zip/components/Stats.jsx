"use client";

import { useEffect, useState } from "react";
import CountUp from "react-countup";
import { db } from "@/lib/firebase";
import {
  collection, doc, onSnapshot, setDoc,
  addDoc, deleteDoc, query, orderBy,
} from "firebase/firestore";
import useAdmin from "./hook/useAdmin";

export default function Stats() {
  const [items, setItems]   = useState([]);
  const [loaded, setLoaded] = useState(false);
  const { isAdmin }         = useAdmin();

  useEffect(() => {
    const q = query(collection(db, "stats"), orderBy("order", "asc"));
    const unsub = onSnapshot(q, (snap) => {
      setItems(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setLoaded(true);
    });
    return () => unsub();
  }, []);

  if (!loaded) return null;

  const addItem = async () => {
    if (items.length >= 4) return;
    await addDoc(collection(db, "stats"), {
      num: 0, text: "Nouvelle stat", visible: true,
      order: (items[items.length - 1]?.order || 0) + 1,
    });
  };
  const removeItem = async (id) => deleteDoc(doc(db, "stats", id));
  const updateItem = async (id, patch) =>
    setDoc(doc(db, "stats", id), patch, { merge: true });

  /* ── MODE VISITEUR — style magazine ── */
  if (!isAdmin) {
    const visible = items.filter((it) => it.visible);
    return (
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {visible.map((item, i) => (
          <div key={item.id} style={{
            flex: '1 1 160px',
            padding: '32px 40px',
            borderRight: i < visible.length - 1 ? '1px solid rgb(var(--ink)/0.08)' : 'none',
            display: 'flex', flexDirection: 'column', gap: '6px',
          }}>
            {/* Nombre en Cormorant massif */}
            <div style={{
              fontFamily: "'Cormorant Garamond',serif",
              fontSize: 'clamp(48px, 6vw, 80px)',
              fontWeight: 700, lineHeight: 1,
              letterSpacing: '-0.04em',
              color: 'rgb(var(--ink))',
            }}>
              <CountUp end={item.num} duration={3} />
              <span style={{ color: 'rgb(var(--rouge))' }}>.</span>
            </div>
            {/* Label en DM Mono */}
            <p style={{
              fontFamily: "'DM Mono',monospace",
              fontSize: '10px', letterSpacing: '0.16em',
              textTransform: 'uppercase',
              color: 'rgb(var(--ink)/0.45)',
              lineHeight: 1.5,
              maxWidth: '120px',
            }}>{item.text}</p>
          </div>
        ))}
      </div>
    );
  }

  /* ── MODE ADMIN ── */
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', alignItems: 'center', padding: '24px' }}>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
        {items.map((item) => (
          <div key={item.id} style={{
            display: 'flex', flexDirection: 'column', gap: '8px',
            padding: '16px', width: '200px',
            border: '1px solid rgb(var(--ink)/0.12)',
            background: 'rgb(var(--cream-dark))',
          }}>
            <label style={{ fontFamily: "'DM Mono',monospace", fontSize: '9px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgb(var(--ink)/0.4)' }}>Nombre</label>
            <input type="number" defaultValue={item.num}
              onBlur={(e) => updateItem(item.id, { num: Number(e.target.value) })}
              style={{ border: '1px solid rgb(var(--ink)/0.15)', background: 'rgb(var(--cream))', padding: '4px 8px', fontFamily: "'DM Mono',monospace", fontSize: '12px', color: 'rgb(var(--ink))' }}
            />
            <label style={{ fontFamily: "'DM Mono',monospace", fontSize: '9px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgb(var(--ink)/0.4)' }}>Texte</label>
            <input type="text" maxLength={30} defaultValue={item.text}
              onBlur={(e) => updateItem(item.id, { text: e.target.value })}
              style={{ border: '1px solid rgb(var(--ink)/0.15)', background: 'rgb(var(--cream))', padding: '4px 8px', fontFamily: "'DM Mono',monospace", fontSize: '12px', color: 'rgb(var(--ink))' }}
            />
            <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontFamily: "'DM Mono',monospace", fontSize: '9px', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'rgb(var(--ink)/0.4)' }}>
              <input type="checkbox" defaultChecked={!!item.visible}
                onChange={(e) => updateItem(item.id, { visible: e.target.checked })}
              />
              Visible
            </label>
            <button onClick={() => removeItem(item.id)}
              style={{ color: 'rgb(184 74 47)', fontFamily: "'DM Mono',monospace", fontSize: '9px', letterSpacing: '0.1em', textTransform: 'uppercase', background: 'none', border: 'none', textAlign: 'left' }}>
              Supprimer
            </button>
          </div>
        ))}
      </div>
      {items.length < 4 && (
        <button onClick={addItem}
          style={{ fontFamily: "'DM Mono',monospace", fontSize: '9px', letterSpacing: '0.15em', textTransform: 'uppercase', padding: '8px 20px', background: 'rgb(var(--ink))', color: 'rgb(var(--cream))', border: 'none' }}>
          + Ajouter une stat
        </button>
      )}
    </div>
  );
}