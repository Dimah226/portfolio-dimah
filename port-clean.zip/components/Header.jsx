'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState, useEffect } from 'react';
import { useLang } from '@/context/LangContext';
import { LOCALES, LOCALE_LABELS } from '@/lib/i18n';
import useAdmin from '@/components/hook/useAdmin';
import { db } from '@/lib/firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { CldImage } from 'next-cloudinary';

export const NAV_PATHS = [
  { key: 'home',     path: '/' },
  { key: 'about',    path: '/about' },
  { key: 'services', path: '/services' },
  { key: 'work',     path: '/work' },
  { key: 'resume',   path: '/resume' },
  { key: 'contact',  path: '/contact' },
];

function AdminToggle({ adminMode, onToggle }) {
  return (
    <div onClick={onToggle} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
      <span style={{ fontFamily: "'DM Mono',monospace", fontSize: '11px', letterSpacing: '0.1em', color: adminMode ? 'rgb(var(--ink)/0.35)' : 'rgb(var(--rouge))', transition: 'color .2s' }}>preview</span>
      <div style={{ width: '36px', height: '20px', background: adminMode ? 'rgb(var(--rouge))' : 'rgb(var(--ink)/0.15)', borderRadius: '10px', position: 'relative', transition: 'background .25s', flexShrink: 0, border: '1px solid rgb(var(--ink)/0.12)' }}>
        <div style={{ position: 'absolute', top: '3px', left: adminMode ? '18px' : '3px', width: '12px', height: '12px', borderRadius: '50%', background: 'white', transition: 'left .25s', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }} />
      </div>
      <span style={{ fontFamily: "'DM Mono',monospace", fontSize: '11px', letterSpacing: '0.1em', color: adminMode ? 'rgb(var(--rouge))' : 'rgb(var(--ink)/0.35)', transition: 'color .2s' }}>admin</span>
    </div>
  );
}

export default function Header() {
  const pathname = usePathname();
  const { lang, setLang, tr } = useLang();
  const { isAdminRaw, adminMode, toggleAdminMode } = useAdmin();
  const [menuOpen, setMenuOpen] = useState(false);
  const [avatarId, setAvatarId] = useState(null);

  // Charge la photo depuis Firestore pour le menu
  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'setting', 'home'), (snap) => {
      if (snap.exists()) setAvatarId(snap.data().avatarPublicId || null);
    });
    return () => unsub();
  }, []);

  // Ferme le menu quand on change de page
  useEffect(() => { setMenuOpen(false); }, [pathname]);

  return (
    <>
      <header style={{
        borderBottom: '1px solid rgb(var(--ink)/0.1)',
        background: 'rgb(var(--parchment))',
        backdropFilter: 'blur(12px)',
        position: 'sticky', top: 0, zIndex: 100,
      }}>
        {/* ── Bande supérieure ── */}
        <div style={{ borderBottom: '1px solid rgb(var(--ink)/0.08)', padding: '5px 36px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontFamily: "'DM Mono',monospace", fontSize: '11px', letterSpacing: '0.16em', color: 'rgb(var(--ink)/0.45)', textTransform: 'uppercase' }}>
            Portfolio · Hamid · Statisticien &amp; Actuaire
          </span>
          <div style={{ display: 'flex', gap: '14px' }}>
            {LOCALES.map((l) => (
              <button key={l} onClick={() => setLang(l)} style={{
                fontFamily: "'DM Mono',monospace", fontSize: '11px', letterSpacing: '0.15em',
                textTransform: 'uppercase', background: 'none', border: 'none', padding: '0',
                color: lang === l ? 'rgb(var(--rouge))' : 'rgb(var(--ink)/0.4)',
                fontWeight: lang === l ? 700 : 400,
                borderBottom: lang === l ? '1px solid rgb(var(--rouge))' : '1px solid transparent',
                paddingBottom: '1px',
              }}>{LOCALE_LABELS[l]}</button>
            ))}
          </div>
        </div>

        {/* ── Ligne principale ── */}
        <div style={{ padding: '0 36px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '60px' }}>
          {/* Logo */}
          <Link href="/" data-cursor-hover>
            <span style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: '28px', fontWeight: 700, letterSpacing: '-0.03em', color: 'rgb(var(--ink))', lineHeight: 1 }}>
              DIMAH<span style={{ color: 'rgb(var(--rouge))' }}>.</span>
            </span>
          </Link>

          {/* Nav desktop */}
          <nav style={{ display: 'flex', alignItems: 'center', gap: '32px' }} className="hidden xl:flex">
            {NAV_PATHS.map(({ key, path }) => {
              const active = pathname === path;
              return (
                <Link key={path} href={path} data-cursor-hover style={{
                  fontFamily: "'DM Mono',monospace",
                  fontSize: '12px',           /* ↑ était 10px */
                  letterSpacing: '0.16em', textTransform: 'uppercase',
                  color: active ? 'rgb(var(--rouge))' : 'rgb(var(--ink)/0.6)',  /* ↑ était 0.45 */
                  borderBottom: active ? '1px solid rgb(var(--rouge))' : '1px solid transparent',
                  paddingBottom: '2px', transition: 'color .2s',
                }}>{tr.nav[key]}</Link>
              );
            })}
          </nav>

          {/* Droite */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
            {/* Toggle admin desktop */}
            

            {/* Bouton contact */}
            <Link href="/contact" data-cursor-hover className="hidden xl:block" style={{
              fontFamily: "'DM Mono',monospace", fontSize: '11px', letterSpacing: '0.18em',
              textTransform: 'uppercase', padding: '9px 20px',
              background: 'rgb(var(--ink))', color: 'rgb(var(--cream))',
            }}>{tr.hire}</Link>

            {/* Burger */}
            <button
              className="xl:hidden"
              onClick={() => setMenuOpen(true)}
              style={{ background: 'none', border: 'none', display: 'flex', flexDirection: 'column', gap: '5px', padding: '4px' }}
              aria-label="Menu"
            >
              {[0, 1, 2].map((i) => (
                <div key={i} style={{ width: '24px', height: '1.5px', background: 'rgb(var(--ink))', transition: 'all .2s' }} />
              ))}
            </button>
          </div>
        </div>
      </header>

      {/* ── MENU SLIDE — panneau latéral droit avec photo ── */}
      {/* Overlay sombre */}
      {menuOpen && (
        <div
          onClick={() => setMenuOpen(false)}
          style={{ position: 'fixed', inset: 0, zIndex: 190, background: 'rgba(14,12,8,0.5)', backdropFilter: 'blur(2px)' }}
        />
      )}

      {/* Panneau */}
      <div style={{
        position: 'fixed', top: 0, right: 0, bottom: 0, zIndex: 200,
        width: 'min(420px, 92vw)',
        background: 'rgb(var(--ink))',
        transform: menuOpen ? 'translateX(0)' : 'translateX(100%)',
        transition: 'transform 0.45s cubic-bezier(0.16, 1, 0.3, 1)',
        display: 'flex', flexDirection: 'column',
        overflow: 'hidden',
      }}>
        {/* Photo en fond partiel */}
        {avatarId && (
          <div style={{ position: 'absolute', inset: 0, opacity: 0.12, pointerEvents: 'none' }}>
            <CldImage src={avatarId} alt="" fill style={{ objectFit: 'cover', objectPosition: 'center top' }} sizes="420px" />
          </div>
        )}

        {/* Contenu */}
        <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', height: '100%', padding: '32px 40px' }}>

          {/* Header du panneau */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '48px' }}>
            <span style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: '24px', fontWeight: 700, letterSpacing: '-0.03em', color: 'rgb(var(--cream))' }}>
              DIMAH<span style={{ color: 'rgb(var(--rouge))' }}>.</span>
            </span>
            <button onClick={() => setMenuOpen(false)} style={{
              background: 'none', border: '1px solid rgb(var(--cream)/0.2)',
              color: 'rgb(var(--cream)/0.6)', width: '36px', height: '36px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: "'DM Mono',monospace", fontSize: '14px',
            }}>✕</button>
          </div>

          {/* Photo portrait si disponible */}
          {avatarId && (
            <div style={{ width: '72px', height: '72px', marginBottom: '32px', border: '1px solid rgb(var(--rouge)/0.4)', overflow: 'hidden', flexShrink: 0, position: 'relative' }}>
              <CldImage src={avatarId} alt="Hamid" fill style={{ objectFit: 'cover', objectPosition: 'center top' }} sizes="72px" />
            </div>
          )}

          {/* Tagline */}
          <p style={{ fontFamily: "'DM Mono',monospace", fontSize: '10px', letterSpacing: '0.18em', textTransform: 'uppercase', color: 'rgb(var(--cream)/0.3)', marginBottom: '40px' }}>
            Statisticien · Économiste · Actuaire
          </p>

          {/* Liens nav */}
          <nav style={{ display: 'flex', flexDirection: 'column', gap: '4px', flex: 1 }}>
            {NAV_PATHS.map(({ key, path }, i) => {
              const active = pathname === path;
              return (
                <Link
                  key={path} href={path}
                  onClick={() => setMenuOpen(false)}
                  style={{
                    fontFamily: "'Cormorant Garamond',serif",
                    fontSize: '36px', fontWeight: active ? 700 : 300,
                    fontStyle: active ? 'normal' : 'italic',
                    color: active ? 'rgb(var(--rouge))' : 'rgb(var(--cream)/0.7)',
                    letterSpacing: '-0.02em', lineHeight: 1.2,
                    borderBottom: '1px solid rgb(var(--cream)/0.06)',
                    padding: '10px 0',
                    transition: 'color .2s',
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  }}
                  onMouseEnter={(e) => { if (!active) e.currentTarget.style.color = 'rgb(var(--cream))'; }}
                  onMouseLeave={(e) => { if (!active) e.currentTarget.style.color = 'rgb(var(--cream)/0.7)'; }}
                >
                  {tr.nav[key]}
                  <span style={{ fontFamily: "'DM Mono',monospace", fontSize: '11px', color: 'rgb(var(--cream)/0.2)', letterSpacing: '0.1em' }}>
                    0{i + 1}
                  </span>
                </Link>
              );
            })}
          </nav>

          {/* Bas : langues + toggle admin */}
          <div style={{ marginTop: '32px', paddingTop: '20px', borderTop: '1px solid rgb(var(--cream)/0.08)' }}>
            <div style={{ display: 'flex', gap: '16px', marginBottom: isAdminRaw ? '16px' : '0' }}>
              {LOCALES.map((l) => (
                <button key={l} onClick={() => setLang(l)} style={{
                  fontFamily: "'DM Mono',monospace", fontSize: '12px', letterSpacing: '0.15em',
                  background: 'none', border: 'none',
                  color: lang === l ? 'rgb(var(--rouge))' : 'rgb(var(--cream)/0.3)',
                  fontWeight: lang === l ? 700 : 400,
                  textTransform: 'uppercase',
                }}>{LOCALE_LABELS[l]}</button>
              ))}
            </div>

            {/* Toggle admin dans le menu aussi */}
            {isAdminRaw && (
              <div onClick={toggleAdminMode} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <span style={{ fontFamily: "'DM Mono',monospace", fontSize: '11px', letterSpacing: '0.1em', color: adminMode ? 'rgb(var(--cream)/0.3)' : 'rgb(var(--rouge))', transition: 'color .2s' }}>preview</span>
                <div style={{ width: '36px', height: '20px', background: adminMode ? 'rgb(var(--rouge))' : 'rgb(var(--cream)/0.15)', borderRadius: '10px', position: 'relative', transition: 'background .25s', border: '1px solid rgb(var(--cream)/0.15)' }}>
                  <div style={{ position: 'absolute', top: '3px', left: adminMode ? '18px' : '3px', width: '12px', height: '12px', borderRadius: '50%', background: 'white', transition: 'left .25s' }} />
                </div>
                <span style={{ fontFamily: "'DM Mono',monospace", fontSize: '11px', letterSpacing: '0.1em', color: adminMode ? 'rgb(var(--rouge))' : 'rgb(var(--cream)/0.3)', transition: 'color .2s' }}>admin</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}