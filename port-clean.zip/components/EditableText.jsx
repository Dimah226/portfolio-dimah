// components/EditableText.jsx
"use client";

import { useEffect, useRef, useState } from "react";
import { setDoc, onSnapshot } from "firebase/firestore";
import useAdmin from "@/components/hook/useAdmin";
import { useLang } from "@/context/LangContext";

/* Cache mémoire — évite de retraduire le même texte */
const cache = {};

export default function EditableText({
  value = "",
  docRef,
  as: Tag = "span",
  className,
  multiline = false,
  style,
}) {
  const { isAdmin }  = useAdmin();
  const { lang }     = useLang();

  const [text, setText]           = useState(value);      // texte FR (source)
  const [displayed, setDisplayed] = useState(value);      // texte affiché (traduit)
  const [editing, setEditing]     = useState(false);
  const [saving, setSaving]       = useState(false);
  const [translating, setTrans]   = useState(false);

  /* Écoute Firestore */
  useEffect(() => {
    if (!docRef) return;
    const unsub = onSnapshot(docRef, (snap) => {
      if (snap.exists() && snap.data().valeur !== undefined) {
        setText(snap.data().valeur);
      }
    });
    return () => unsub();
  }, [docRef]);

  /* Traduit quand text ou lang change */
  useEffect(() => {
    if (lang === 'fr' || !text?.trim()) {
      setDisplayed(text);
      return;
    }
    const key = `${docRef?.path || text}§${lang}§${text}`;
    if (cache[key]) { setDisplayed(cache[key]); return; }

    let dead = false;
    setTrans(true);
    fetch('/api/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, targetLang: lang }),
    })
      .then(r => r.json())
      .then(({ translated }) => {
        if (dead) return;
        cache[key] = translated;
        setDisplayed(translated);
      })
      .catch(() => { if (!dead) setDisplayed(text); })
      .finally(() => { if (!dead) setTrans(false); });

    return () => { dead = true; };
  }, [text, lang]);

  const save = async () => {
    if (!docRef) return;
    setSaving(true);
    await setDoc(docRef, { valeur: text }, { merge: true });
    setSaving(false);
    setEditing(false);
    // Invalide le cache pour ce doc
    if (docRef?.path) {
      Object.keys(cache).forEach(k => {
        if (k.startsWith(docRef.path)) delete cache[k];
      });
    }
  };

  /* ── Mode visiteur ── */
  if (!isAdmin) {
    return (
      <Tag className={className} style={{
        ...style,
        opacity: translating ? 0.45 : 1,
        transition: 'opacity 0.4s',
      }}>
        {displayed || value}
      </Tag>
    );
  }

  /* ── Mode admin : édition (toujours en FR) ── */
  if (editing) {
    const common = {
      value: text,
      onChange: (e) => setText(e.target.value),
      onBlur: save,
      autoFocus: true,
      style: {
        background: 'rgb(var(--cream))',
        color: 'rgb(var(--ink))',
        border: '1px dashed rgb(var(--rouge)/0.7)',
        outline: 'none', padding: '2px 6px', width: '100%',
        fontFamily: 'inherit', fontSize: 'inherit',
        fontWeight: 'inherit', lineHeight: 'inherit',
        letterSpacing: 'inherit', fontStyle: 'inherit',
        ...style,
      },
    };
    return multiline
      ? <textarea {...common} rows={3} onKeyDown={e => e.key === 'Escape' && setEditing(false)} />
      : <input {...common} onKeyDown={e => { if (e.key === 'Enter') save(); if (e.key === 'Escape') setEditing(false); }} />;
  }

  /* ── Mode admin : lecture ── */
  return (
    <Tag className={className} style={{
      ...style,
      cursor: 'text',
      borderBottom: '1px dashed rgb(var(--rouge)/0.5)',
    }}
      title={saving ? 'Enregistrement…' : '✏ Éditer (FR → traduit auto)'}
      onClick={() => setEditing(true)}
    >
      {text || <span style={{ opacity: 0.4, fontStyle: 'italic' }}>Cliquer pour écrire…</span>}
    </Tag>
  );
}