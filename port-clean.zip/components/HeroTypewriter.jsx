'use client';
import { useEffect, useState } from 'react';

const PHRASES = [
  'Modéliser l\'incertitude.',
  'Quantifier le risque.',
  'Transformer la donnée.',
  'Prévoir. Décider. Agir.',
  'Du bruit au signal.',
  'L\'actuaire & le data scientist.',
  'IBNR. XGBoost. LSTM.',
  'Abidjan → Afrique → monde.',
];

export default function HeroTypewriter() {
  const [phraseIdx, setPhraseIdx] = useState(0);
  const [displayed, setDisplayed]  = useState('');
  const [phase, setPhase]          = useState('typing');

  useEffect(() => {
    const phrase = PHRASES[phraseIdx];
    let timeout;

    if (phase === 'typing') {
      if (displayed.length < phrase.length) {
        timeout = setTimeout(() => setDisplayed(phrase.slice(0, displayed.length + 1)), 42);
      } else {
        timeout = setTimeout(() => setPhase('pause'), 1800);
      }
    }
    if (phase === 'pause') {
      timeout = setTimeout(() => setPhase('erasing'), 200);
    }
    if (phase === 'erasing') {
      if (displayed.length > 0) {
        timeout = setTimeout(() => setDisplayed(displayed.slice(0, -1)), 22);
      } else {
        setPhraseIdx((i) => (i + 1) % PHRASES.length);
        setPhase('typing');
      }
    }

    return () => clearTimeout(timeout);
  }, [displayed, phase, phraseIdx]);

  return (
    <div style={{ minHeight: '2.4em', display: 'flex', alignItems: 'center' }}>
      <span style={{
        fontFamily: "'Cormorant Garamond',serif",
        fontSize: 'clamp(32px, 3.8vw, 56px)',  /* était clamp(28px, 3.2vw, 48px) */
        fontWeight: 400,
        fontStyle: 'italic',
        color: 'rgb(var(--ink)/0.22)',
        lineHeight: 1.15,
        letterSpacing: '-0.02em',
        whiteSpace: 'pre',
      }}>
        {displayed}
        <span style={{
          display: 'inline-block', width: '2px', height: '0.8em',
          background: 'rgb(var(--rouge)/0.6)', marginLeft: '3px',
          verticalAlign: 'middle', animation: 'blink 1s step-end infinite',
        }} />
      </span>
      <style>{`@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }`}</style>
    </div>
  );
}