'use client';
import { useLang } from '@/context/LangContext';

export default function Footer() {
  const { tr } = useLang();
  const year = new Date().getFullYear();

  return (
    <footer style={{
      background: 'rgb(var(--ink))',
      color: 'rgb(var(--cream))',
      borderTop: '1px solid rgb(var(--ink)/0.1)',
    }}>
      {/* Ligne unique — signature à gauche, copyright à droite */}
      <div style={{
        padding: '28px 48px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderBottom: '1px solid rgb(var(--cream)/0.05)',
      }}>
        {/* Masthead compact */}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: '16px' }}>
          <span style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: '28px', fontWeight: 700, letterSpacing: '-0.04em', lineHeight: 1 }}>
            DIMAH<span style={{ color: 'rgb(var(--rouge))' }}>.</span>
          </span>
          <span style={{ fontFamily: "'DM Mono',monospace", fontSize: '9px', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgb(var(--cream)/0.25)' }}>
            {tr.footer.tagline}
          </span>
        </div>

        {/* Copyright */}
        <span style={{ fontFamily: "'DM Mono',monospace", fontSize: '9px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgb(var(--cream)/0.2)' }}>
          © {year} Hamid · {tr.footer.rights}
        </span>
      </div>
    </footer>
  );
}