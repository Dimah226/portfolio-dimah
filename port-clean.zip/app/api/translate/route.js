// app/api/translate/route.js
import { NextResponse } from 'next/server';

export async function POST(req) {
  try {
    const { text, targetLang } = await req.json();

    if (!text?.trim()) return NextResponse.json({ translated: text });
    if (targetLang === 'fr') return NextResponse.json({ translated: text });
    if (!process.env.GROQ_API_KEY) return NextResponse.json({ translated: text });

    const prompts = {
      en: `You are a professional translator. Translate the following French text to English.
Rules:
- Output ONLY the translated text, nothing else
- No quotes, no explanations, no comments
- Keep the same professional and concise tone
- Preserve proper nouns (names, cities, institutions)`,

      ar: `أنت مترجم محترف. ترجم النص الفرنسي التالي إلى العربية الفصحى.
القواعد:
- أخرج النص المترجم فقط، لا شيء آخر
- بدون علامات اقتباس أو شرح
- احتفظ بنفس الأسلوب المهني والدقيق
- حافظ على الأسماء الصحيحة (أسماء الأشخاص، المدن، المؤسسات)
- استخدم العربية الفصحى الرسمية`,
    };

    const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'llama-3.1-8b-instant',
        max_tokens: 400,
        temperature: 0.1,
        messages: [
          { role: 'system', content: prompts[targetLang] },
          { role: 'user', content: text },
        ],
      }),
    });

    const data = await res.json();
    if (!res.ok) return NextResponse.json({ translated: text }, { status: res.status });

    const translated = data.choices?.[0]?.message?.content?.trim() || text;
    return NextResponse.json({ translated });

  } catch (err) {
    return NextResponse.json({ translated: '' }, { status: 500 });
  }
}